for i in range(8):
   for j in range(i+1):
      print("*",end="")
   print()