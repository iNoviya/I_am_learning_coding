output = dict()

for i in range(8):
   text =(i+1)*"*"
   output[i] = text
for i in range(8):
   print(output[i])