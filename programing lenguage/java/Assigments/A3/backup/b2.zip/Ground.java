public class Ground {

   private String _groundName;
   private String _url;

   public Ground(){}
   public Ground(String groundName, String url){
      this._groundName = groundName;
      this._url = url;
   }

   public void setGroundName(String groundName) {
      this._groundName = groundName;
   }
   public String getGroundName(){
      return _groundName;
   }
   public String getUrl(){
      return _url;
   }

   private static Ground instance;
   public static synchronized Ground getInstance() {
      if (instance == null) {
         instance = new Ground();
      }
      return instance;
   }
}