import java.util.List;

import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;


public class Background  {

   private static final int WIDTH = GameSetting.getInstance().getWidth();
   private static final int HEIGHT = GameSetting.getInstance().getHeight();
   private static final int PIXEL_WEIGHT = GameSetting.getInstance().getPixelWeight();
   private static final int earthLine = GameSetting.getInstance().getEarthLine();
   private static final double lavaProbabilities = GameSetting.getInstance().getLavaProbabilities();
   private  static  final  int mineralProbabilities = GameSetting.getInstance().getMineralProbabilities();
   private final List<Ground> _groundList;

   private final List<Minerals> _mineralsList;
   private final Pane _root;

   private static String[][] _gameMap = new String[WIDTH][HEIGHT];

   public Background(List<Ground> groundList, List<Minerals> mineralsList, Pane root) {
      _groundList = groundList;
      _mineralsList = mineralsList;
      _root = root;
   }

   public String[][]  backgroundSetter() {
      for (int y = 0; y < HEIGHT; y += 1) {
         for (int x = 0; x < WIDTH; x += 1) {
            int mineralRound = (int) Math.round(Math.random() * 10);
            if (y < earthLine) {
               Color color = Color.BLUE;
               Rectangle rect = new Rectangle(PIXEL_WEIGHT, PIXEL_WEIGHT+3, color);
               rect.setX(x*PIXEL_WEIGHT);
               rect.setY(y*PIXEL_WEIGHT);
               _root.getChildren().add(rect);
               _gameMap[x][y] = "sky";

            } else if (y == earthLine) {
               Assets tile = new Assets(_groundList.get(0).getUrl(),PIXEL_WEIGHT);
               tile.getImageView().setX(x*PIXEL_WEIGHT);
               tile.getImageView().setY(y*PIXEL_WEIGHT);
               _root.getChildren().add(tile.getImageView());
               _gameMap[x][y] = "soil";

            } else {
               if (y == HEIGHT -1 ) {
                  Assets stone = new Assets(_groundList.get(2).getUrl(),PIXEL_WEIGHT);
                  stone.getImageView().setX(x*PIXEL_WEIGHT);
                  stone.getImageView().setY(y*PIXEL_WEIGHT);
                  _root.getChildren().add(stone.getImageView());
                  _gameMap[x][y] = "obstacle";
               } else {
                  if (x == 0 || x == WIDTH-1){
                     Assets stone = new Assets(_groundList.get(2).getUrl(),PIXEL_WEIGHT);
                     stone.getImageView().setX(x*PIXEL_WEIGHT);
                     stone.getImageView().setY(y*PIXEL_WEIGHT);
                     _root.getChildren().add(stone.getImageView());
                     _gameMap[x][y] = "obstacle";
                  } else {
                     if (mineralRound < lavaProbabilities){
                        Assets lava = new Assets(_groundList.get(3).getUrl(),PIXEL_WEIGHT);
                        lava.getImageView().setX(x*PIXEL_WEIGHT);
                        lava.getImageView().setY(y*PIXEL_WEIGHT);
                        _root.getChildren().add(lava.getImageView());
                        _gameMap[x][y] = "lava";

                     } else if (mineralRound > mineralProbabilities) {
                        Assets minerals = new Assets(_mineralsList.get((int) Math.round(Math.random() * 9)).getUrl(),PIXEL_WEIGHT);
                        minerals.getImageView().setX(x*PIXEL_WEIGHT);
                        minerals.getImageView().setY(y*PIXEL_WEIGHT);
                        _root.getChildren().add(minerals.getImageView());
                        _gameMap[x][y] = _mineralsList.get((int) Math.round(Math.random() * 9)).getMineralName();

                     } else {
                        Assets soil = new Assets(_groundList.get(1).getUrl(),PIXEL_WEIGHT);
                        soil.getImageView().setX(x*PIXEL_WEIGHT);
                        soil.getImageView().setY(y*PIXEL_WEIGHT);
                        _root.getChildren().add(soil.getImageView());
                        _gameMap[x][y] = "soil";
                     }
                  }
               }
            }
         }
      }
      return _gameMap;
   }
}
