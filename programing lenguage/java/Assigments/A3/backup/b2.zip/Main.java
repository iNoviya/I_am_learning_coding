import javafx.animation.AnimationTimer;
import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import java.util.ArrayList;
import java.util.List;
import javafx.scene.control.Label;
import java.util.Timer;

public class Main extends Application {

   private static final int WIDTH = 16;
   private static final int HEIGHT = 12;
   private static final int PIXEL_WEIGHT = 50;
   private static final int earthLine = 2;
   private static final double lavaProbabilities = 0.2;
   private static final int mineralProbabilities = 8;
   private static double _fuel = 100;
   private static double _money = 0;
   private static double _machineWeight = 0;

   @Override
   public void start(Stage primaryStage) throws InterruptedException {
      GameSetting gameSetting = new GameSetting(WIDTH, HEIGHT, PIXEL_WEIGHT, earthLine, lavaProbabilities, mineralProbabilities);

      Image icon = new Image("file:src/assets/drill/drill_19.png");
      primaryStage.getIcons().add(icon);

      Pane root = new Pane();
      Scene scene = new Scene(root, WIDTH * PIXEL_WEIGHT, HEIGHT * PIXEL_WEIGHT, Color.BROWN);

      Label scoreLabel = new Label("Money : " + _money);
      scoreLabel.setLayoutX(25);
      scoreLabel.setLayoutY(10);
      scoreLabel.setFont(new Font(25));
      scoreLabel.setTextFill(Color.WHITE);
      scoreLabel.toFront();

      Label weightScore = new Label("Weight : " + _machineWeight);
      weightScore.setLayoutX(25);
      weightScore.setLayoutY(35);
      weightScore.setFont(new Font(25));
      weightScore.setTextFill(Color.WHITE);
      weightScore.toFront();

      Label fuelLevel = new Label("Fuel : " + _fuel);
      fuelLevel.setLayoutX(25);
      fuelLevel.setLayoutY(60);
      fuelLevel.setFont(new Font(25));
      fuelLevel.setTextFill(Color.WHITE);
      fuelLevel.toFront();

      AssetsMeasurement assetsMeasurement = new AssetsMeasurement();

      List<Ground> groundList = assetsMeasurement.loadEarthAssets();
      List<Minerals> mineralsList = assetsMeasurement.loadMineralAssets();

      Background background = new Background(groundList, mineralsList, root);
      String[][] gameMap = background.backgroundSetter();


      Assets machine = new Assets("file:src/assets/drill/drill_37.png", 55);
      machine.getImageView().setX(PIXEL_WEIGHT * WIDTH / 2);
      machine.getImageView().setY(55);

      machine.getImageView().toFront();
      root.getChildren().add(machine.getImageView());

      decreaseFuelManually(fuelLevel,1,root);

      AnimationTimer timer = new AnimationTimer() {
         private long lastUpdate = 0;
         @Override
         public void handle(long now) {
            if (now - lastUpdate >= 1_000_000_000) {
               decreaseFuel(fuelLevel, 1);
               lastUpdate = now;
            }
         }
      };
      timer.start();


      AnimationTimer gravityTimer = new AnimationTimer() {
         private long lastUpdate = 0;

         @Override
         public void handle(long now) {
            if (now - lastUpdate >= 1000 * 1_000_000) {
               if (isCollision(machine.getImageView().getX(), machine.getImageView().getY() + PIXEL_WEIGHT, "empty",gameMap)) {
                  machine.getImageView().setY(machine.getImageView().getY() + PIXEL_WEIGHT);
               }
               lastUpdate = now;
            }
         }
      };
      gravityTimer.start();

      scene.setOnKeyPressed(event -> {

         decreaseFuelManually(fuelLevel,1,root);
         double newX = machine.getImageView().getX();
         double newY = machine.getImageView().getY();


         if (event.getCode() == KeyCode.RIGHT || event.getCode() == KeyCode.D) {
            newX += PIXEL_WEIGHT;
         } else if (event.getCode() == KeyCode.LEFT || event.getCode() == KeyCode.A) {
            newX -= PIXEL_WEIGHT;
         } else if ((event.getCode() == KeyCode.UP || event.getCode() == KeyCode.W) && (isCollision(newX, newY - PIXEL_WEIGHT, "empty", gameMap) || (isCollision(newX, newY - PIXEL_WEIGHT, "sky", gameMap)))) {
            newY -= PIXEL_WEIGHT;
         } else if (event.getCode() == KeyCode.DOWN || event.getCode() == KeyCode.S) {
            newY += PIXEL_WEIGHT;
         }
         if (!isCollision(newX, newY, "obstacle", gameMap)) {

//
            /*while (isBlankUnderneath(newX, newY , gameMap)) {
               newY += PIXEL_WEIGHT;
               machine.getImageView().setY(newY);
            }*/
            machine.getImageView().setX(newX);
            machine.getImageView().setY(newY);
            String mineType = findMineType(gameMap, newX, newY);
            switch (mineType) {
               case "soil": {
                  Color color = Color.DARKRED;
                  Rectangle rect = new Rectangle(PIXEL_WEIGHT, PIXEL_WEIGHT, color);
                  rect.setX(newX);
                  rect.setY(newY);
                  root.getChildren().add(rect);
                  gameMap[(int) Math.round((double) newX / PIXEL_WEIGHT)][(int) (Math.round((double) newY / PIXEL_WEIGHT))] = "empty";
                  break;
               }
               case "sky": {

                  break;
               }
               case "lava": {
                  gameOver(root,"darkred");
                  break;
               }
               default: {
                  List<Integer> mineralFeatures =  findMineralFeature(gameMap, newX, newY, mineralsList);
                  int mineWorth = mineralFeatures.get(0);
                  int mineWeight = mineralFeatures.get(1);
                  Color color = Color.DARKRED;
                  Rectangle rect = new Rectangle(PIXEL_WEIGHT, PIXEL_WEIGHT, color);
                  rect.setX(newX);
                  rect.setY(newY);
                  moneyScore(scoreLabel, mineWorth);
                  weightScore(weightScore, mineWeight);
                  decreaseFuelManually(fuelLevel,5,root);
                  root.getChildren().add(rect);
                  gameMap[(int) Math.round((double) newX / PIXEL_WEIGHT)][(int) (Math.round((double) newY / PIXEL_WEIGHT))] = "empty";
                  break;
               }
            }
            machine.getImageView().toFront();
         }
      });
      
      root.getChildren().addAll(scoreLabel,fuelLevel,weightScore);
      primaryStage.setTitle("HU-LOAD");
      primaryStage.setResizable(false);
      primaryStage.setScene(scene);
      primaryStage.show();
   }

   private boolean isCollision(double newX, double newY, String type, String[][] gameMap) {
      String object = gameMap[(int) Math.round((double) newX / PIXEL_WEIGHT)][(int) (Math.round((double) newY / PIXEL_WEIGHT))];
      if (object.equals(type)) {
         return true;
      }
      return false;
   }

   public String findMineType(String[][] gameMap, double newX, double newY) {
      return gameMap[(int) Math.round((double) newX / PIXEL_WEIGHT)][(int) (Math.round((double) newY / PIXEL_WEIGHT))];
   }

   public List<Integer> findMineralFeature (String[][] gameMap, double newX, double newY, List<Minerals> mineralsList) {
      String mine = gameMap[(int) Math.round((double) newX / PIXEL_WEIGHT)][(int) (Math.round((double) newY / PIXEL_WEIGHT))];
      List<Integer> mineralsFeatures = new ArrayList<>();
      for (Minerals mineral : mineralsList) {
         if (mineral.getMineralName().equals(mine)) {
            mineralsFeatures.add(mineral.getWorth());
            mineralsFeatures.add(mineral.getWeight());
         }
      }
      return mineralsFeatures;
   }
   private void moneyScore(Label scoreLabel, int worth) {
      _money += worth;
      scoreLabel.setText("Money : " + _money);
      scoreLabel.toFront();
   }
   private void weightScore(Label weightScore, int weight) {
      _machineWeight += weight;
      weightScore.setText("Weight : " + _machineWeight);
      weightScore.toFront();
   }

   private void decreaseFuelManually(Label fuelLevel, double amount,Pane root) {
      if (_fuel > 0) {
         _fuel -= amount;
         fuelLevel.setText("Fuel : " + _fuel);
         fuelLevel.toFront();
      } else {
         gameOver(root,"green");
      }
   }

   private void gameOver(Pane root, String gameOverColor) {
      root.getChildren().clear();
      root.setStyle("-fx-background-color: "+gameOverColor+ ";");
      Label gameOverLabel = new Label("GAME OVER!!!");
      gameOverLabel.setLayoutX(WIDTH * PIXEL_WEIGHT / 3);
      gameOverLabel.setLayoutY(HEIGHT * PIXEL_WEIGHT / 2.5);
      gameOverLabel.setFont(Font.font("Verdana", FontWeight.BOLD, 45));
      gameOverLabel.setTextFill(Color.WHITE);
      root.getChildren().add(gameOverLabel);

      Label gameOverScoreLabel = new Label("YOUR MONEY : " + _money);
      gameOverScoreLabel.setLayoutX(WIDTH * PIXEL_WEIGHT / 3);
      gameOverScoreLabel.setLayoutY(HEIGHT * PIXEL_WEIGHT / 2.5 + 100);
      gameOverScoreLabel.setFont(Font.font("Verdana", FontWeight.BOLD, 30));
      gameOverScoreLabel.setTextFill(Color.WHITE);
      root.getChildren().add(gameOverScoreLabel);
   }

   private void decreaseFuel(Label fuelLevel, double amount) {
      _fuel -= amount;
      fuelLevel.setText("Fuel : " + _fuel);
      fuelLevel.toFront();

      if (_fuel <= 0) {
         _fuel = 0;
         fuelLevel.setText("Fuel : " + _fuel);
      }
   }




   public static void main(String[] args) {
      launch(args);
   }
}