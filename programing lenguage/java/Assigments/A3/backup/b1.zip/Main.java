import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import javafx.scene.control.Label;
import static javafx.application.Application.launch;

public class Main extends Application {

   private static final int WIDTH = 16;
   private static final int HEIGHT = 12;
   private static final int PIXEL_WEIGHT =50;
   private static final int earthLine = 2;
   private static final double lavaProbabilities = 0.2;
   private static final int mineralProbabilities = 8;

   private double fuel = 100;
   private double money = 0;
   private boolean gameOver = false;

   @Override
   public void start(Stage primaryStage) {
      GameSetting gameSetting = new GameSetting(WIDTH,HEIGHT,PIXEL_WEIGHT,earthLine,lavaProbabilities,mineralProbabilities);

      Pane root = new Pane();
      Scene scene = new Scene(root, WIDTH*PIXEL_WEIGHT, HEIGHT*PIXEL_WEIGHT,Color.BROWN);


      Label scoreLabel = new Label("Score: " + money);
      scoreLabel.setLayoutX(PIXEL_WEIGHT);
      scoreLabel.setLayoutY(PIXEL_WEIGHT);
      scoreLabel.toFront();
      root.getChildren().add(scoreLabel);


      AssetsMeasurement assetsMeasurement = new AssetsMeasurement();

      List<Ground> groundList = assetsMeasurement.loadEarthAssets();
      List<Minerals> mineralsList = assetsMeasurement.loadMineralAssets();

      Background background = new Background(groundList, mineralsList , root);
      background.backgroundSetter();



      Assets machine = new Assets("file:src/assets/drill/drill_37.png",50);
      machine.getImageView().setX(PIXEL_WEIGHT*WIDTH/2);
      machine.getImageView().setY(60 );
      machine.getImageView().toFront();
      root.getChildren().add(machine.getImageView());

      AtomicReference<Double> newX = new AtomicReference<>(machine.getImageView().getX());
      AtomicReference<Double> newY = new AtomicReference<>(machine.getImageView().getY());
      scene.setOnKeyPressed(event -> {
         if (event.getCode() == KeyCode.RIGHT) {
            newX.updateAndGet(v -> (double) (v + PIXEL_WEIGHT / 4));
         } else if (event.getCode() == KeyCode.LEFT) {
            newX.updateAndGet(v -> (double) (v - PIXEL_WEIGHT / 4));
         }
         else if (event.getCode() == KeyCode.UP) {
            newY.updateAndGet(v -> (double) (v - PIXEL_WEIGHT / 4));
         }
         else if (event.getCode() == KeyCode.DOWN) {
            newY.updateAndGet(v -> (double) (v + PIXEL_WEIGHT / 4));
         }
         newX.set(Math.max(0, Math.min(newX.get(), scene.getWidth() - machine.getImageView().getFitWidth())));
         newY.set(Math.max(0, Math.min(newY.get(), scene.getHeight() - machine.getImageView().getFitHeight())));

         machine.getImageView().setX(newX.get());
         machine.getImageView().setY(newY.get());
      });



      /*machine = new Rectangle(PIXEL_WEIGHT*WIDTH/2, (earthLine-1)*PIXEL_WEIGHT , PIXEL_WEIGHT, PIXEL_WEIGHT);
      machine.setFill(Color.SILVER);
      root.getChildren().add(machine);*/



      Image icon = new Image("file:src/assets/drill/drill_19.png");
      primaryStage.getIcons().add(icon);

      primaryStage.setTitle("HU-LOAD");
      primaryStage.setResizable(false);
      primaryStage.setScene(scene);
      primaryStage.show();


   }


   public static void main(String[] args) {
      launch(args);
   }
}