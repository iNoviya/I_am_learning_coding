import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Assets {

   private ImageView _imageView;

   public Assets(String imagePath , int pixels) {
      Image image = new Image(imagePath);
      this._imageView = new ImageView(image);
      _imageView.setFitHeight(pixels);
      _imageView.setFitWidth(pixels);
   }

   public ImageView getImageView() {
      return _imageView;
   }
}
