import javafx.scene.Scene;
import javafx.scene.layout.Pane;

import java.util.*;

public class AssetsMeasurement extends Main {
   Minerals minerals = new Minerals();
   List<Minerals> mineralsList = new ArrayList<>();
   String baseFileWay ="file:src/assets/underground/";


   public List<Minerals> loadMineralAssets (){
      Minerals amazonite = new Minerals("amazonite",500000,120,baseFileWay + "valuable_amazonite.png");
      mineralsList.add(amazonite);
      Minerals brozinum = new Minerals("bronzium",60,10,baseFileWay + "valuable_bronzium.png");
      mineralsList.add(brozinum);
      Minerals diamond = new Minerals("diamond",60,10,baseFileWay + "valuable_diamond.png");
      mineralsList.add(diamond);
      Minerals einsteinium = new Minerals("einsteinium",60,10,baseFileWay + "valuable_einsteinium.png");
      mineralsList.add(einsteinium);
      Minerals emerald = new Minerals("emerald",60,10,baseFileWay + "valuable_emerald.png");
      mineralsList.add(emerald);
      Minerals goldium = new Minerals("goldium",60,10,baseFileWay + "valuable_goldium.png");
      mineralsList.add(goldium);
      Minerals ironium = new Minerals("ironium",60,10,baseFileWay + "valuable_ironium.png");
      mineralsList.add(ironium);
      Minerals platinium = new Minerals("platinium",60,10,baseFileWay + "valuable_platinium.png");
      mineralsList.add(platinium);
      Minerals ruby = new Minerals("ruby",60,10,baseFileWay + "valuable_ruby.png");
      mineralsList.add(ruby);
      Minerals silverium = new Minerals("silverium",60,10,baseFileWay + "valuable_silverium.png");
      mineralsList.add(silverium);

   return mineralsList;
   }

   List<Ground> groundList = new ArrayList<>();
   public List<Ground> loadEarthAssets (){
      Ground top_01 = new Ground("top1",baseFileWay + "top_01.png");
      groundList.add(top_01);
      Ground soil_01 = new Ground("soil1",baseFileWay + "soil_01.png");
      groundList.add(soil_01);
      Ground obstacle_01 = new Ground("obstacle1",baseFileWay + "obstacle_01.png");
      groundList.add(obstacle_01);
      Ground lava_02 = new Ground("lava2",baseFileWay + "lava_02.png");
      groundList.add(lava_02);

      return groundList;
   }
}
