import java.util.Timer;
import java.util.TimerTask;

public class FuelSystem {
   private static double _fuelLevel;
   private Timer _timer;

   public FuelSystem(double initialFuelLevel) {
      this._fuelLevel = initialFuelLevel;
      startFuelConsumption();
   }

   public void setFullLevel(double fuelLevel){
      this._fuelLevel = fuelLevel;
   }
   public double getFuelLevel(){
      return _fuelLevel;
   }

   private void startFuelConsumption() {
      _timer = new Timer();
      _timer.scheduleAtFixedRate(new TimerTask() {
         @Override
         public void run() {
            decreaseFuel(1);
         }
      }, 1000, 1000);
   }

   public void decreaseFuel(double amount) {
      this._fuelLevel -= amount;
      if (this._fuelLevel < 0) {
         this._fuelLevel = 0;
      }
   }
}