import javafx.scene.control.Label;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
public class LabelManager {
   private static final int LABEL_OFFSET_X = 25;
   private static final int LABEL_FONT_SIZE = 25;
   private static final Color LABEL_TEXT_COLOR = Color.WHITE;

   public static Label createLabel(String text, double layoutX, double layoutY) {
      Label label = new Label(text);
      label.setLayoutX(layoutX + LABEL_OFFSET_X);
      label.setLayoutY(layoutY);
      label.setFont(new Font(LABEL_FONT_SIZE));
      label.setTextFill(LABEL_TEXT_COLOR);
      label.toFront();
      return label;
   }

   public static Label createFuelLabel(double fuel, double layoutX, double layoutY) {
      String formattedFuel = String.format("Fuel : %.3f", fuel);
      return createLabel(formattedFuel, layoutX, layoutY);
   }
}
