/**
 * It is class that allows you to access the properties of minerals.
 */
public class Minerals extends AssetsLoader {
   private String _mineralName;
   private int _worth;
   private int _weight;
   private String _url;

   public Minerals(String mineralName, int worth, int weight , String url){
      this._mineralName = mineralName;
      this._worth = worth;
      this._weight = weight;
      this._url = url;
   }
   public String getMineralName(){
      return _mineralName;
   }
   public int getWorth(){
      return _worth;
   }
   public int getWeight(){
      return _weight;
   }
   public String getUrl(){
      return _url;
   }
}
