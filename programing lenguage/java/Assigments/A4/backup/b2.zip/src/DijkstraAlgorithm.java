import java.util.*;

public class DijkstraAlgorithm {
   public List<Route> findFastestRoute(Neighborhood neighborhood, String startPoint, String endPoint) {
      Map<String, Integer> distances = new HashMap<>();
      Map<String, Route> roadHolder = new HashMap<>();
      Set<String> visitedCity = new HashSet<>();
      PriorityQueue<String> pq = new PriorityQueue<>(Comparator.comparingInt(distances::get));


      for (String city : neighborhood.getNeighborhoodCity()) {
         distances.put(city, Integer.MAX_VALUE);
      }
      distances.put(startPoint, 0);
      pq.add(startPoint);

      while (!pq.isEmpty()) {
         String current = pq.poll();
         if (!visitedCity.add(current)) continue;

         List<Route> routes = neighborhood.getRoutes(current);
         routes.sort(Comparator.comparingInt(Route::getRoadLength).thenComparingInt(Route::getId));

         for (Route route : routes) {
            if (visitedCity.contains(route.getEnd())) continue;
            int newDist = distances.get(current) + route.getRoadLength();
            if (newDist < distances.get(route.getEnd())) {
               distances.put(route.getEnd(), newDist);
               roadHolder.put(route.getEnd(), route);
               pq.add(route.getEnd());
            }
         }
      }

      List<Route> path = new ArrayList<>();
      while (roadHolder.containsKey(endPoint)) {
         Route route = roadHolder.get(endPoint);
         path.add(route);
         endPoint = route.getStart();
      }
      Collections.reverse(path);
      return path;
   }
}
