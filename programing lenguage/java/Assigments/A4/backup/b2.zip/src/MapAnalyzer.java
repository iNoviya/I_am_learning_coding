import java.io.*;
import java.util.*;

public class MapAnalyzer {
   public static void main(String[] args) throws IOException {
      if (args.length != 2) {
         System.err.println("Usage: java MapAnalyzer <input file> <output file>");
         return;
      }

      String inputFile = args[0];
      String outputFile = args[1];

      BufferedReader reader = new BufferedReader(new FileReader(inputFile));
      BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile));

      String[] points = reader.readLine().split("\t");
      String startPoint = points[0];
      String endPoint = points[1];

      Neighborhood neighborhood = new Neighborhood();
      List<Route> allRoutes = new ArrayList<>();

      String line;
      while ((line = reader.readLine()) != null) {
         String[] parts = line.split("\t");
         String start = parts[0];
         String end = parts[1];
         int distance = Integer.parseInt(parts[2]);
         int id = Integer.parseInt(parts[3]);
         Route route = new Route(start, end, distance, id);
         neighborhood.addRoute(route);
         allRoutes.add(route);
      }
      reader.close();

      DijkstraAlgorithm dijkstraAlgorithm = new DijkstraAlgorithm();
      KruskalAlgorithm kruskalAlgorithm = new KruskalAlgorithm();

      List<Route> fastestRoute = dijkstraAlgorithm.findFastestRoute(neighborhood, startPoint, endPoint);
      List<Route> barelyConnectedMap = kruskalAlgorithm.findBarelyConnectedMap(allRoutes);
      List<Route> fastestRouteBarelyConnected = dijkstraAlgorithm.findFastestRoute(new Neighborhood() {{
         barelyConnectedMap.forEach(this::addRoute);
      }}, startPoint, endPoint);

      int originalDistance = fastestRoute.stream().mapToInt(Route::getRoadLength).sum();
      int barelyConnectedDistance = fastestRouteBarelyConnected.stream().mapToInt(Route::getRoadLength).sum();
      int originalMaterial = allRoutes.stream().mapToInt(Route::getRoadLength).sum();
      int barelyConnectedMaterial = barelyConnectedMap.stream().mapToInt(Route::getRoadLength).sum();

      writer.write("Fastest Route from " + startPoint + " to " + endPoint + " (" + originalDistance + " KM):\n");
      for (Route route : fastestRoute) {
         Route originalRoute = neighborhood.getRouteById(route.getId());
         writer.write(originalRoute.getStart() + "\t" + originalRoute.getEnd() + "\t" + originalRoute.getRoadLength() + "\t" + originalRoute.getId() + "\n");
      }

      writer.write("Roads of Barely Connected Map is:\n");
      for (Route route : barelyConnectedMap) {
         Route originalRoute = neighborhood.getRouteById(route.getId());
         writer.write(originalRoute.getStart() + "\t" + originalRoute.getEnd() + "\t" + originalRoute. getRoadLength()   + "\t" + originalRoute.getId() + "\n");
      }

      writer.write("Fastest Route from " + startPoint + " to " + endPoint + " on Barely Connected Map (" + barelyConnectedDistance + " KM):\n");
      for (Route route : fastestRouteBarelyConnected) {
         Route originalRoute = neighborhood.getRouteById(route.getId());
         writer.write(originalRoute.getStart() + "\t" + originalRoute.getEnd() + "\t" + originalRoute.getRoadLength() + "\t" + originalRoute.getId() + "\n");
      }

      writer.write("Analysis:\n");
      writer.write("Ratio of Construction Material Usage Between Barely Connected and Original Map: " + String.format("%.2f", (double) barelyConnectedMaterial / originalMaterial) + "\n");
      writer.write("Ratio of Fastest Route Between Barely Connected and Original Map: " + String.format("%.2f", (double) barelyConnectedDistance / originalDistance) );

      writer.close();
   }
}
