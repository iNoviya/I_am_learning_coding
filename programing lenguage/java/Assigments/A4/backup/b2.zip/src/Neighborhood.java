import java.util.*;

/**
 * This class preserves neighborly relations.
 */

public class Neighborhood {
   private Map<String, List<Route>> _neighborhoodslist;
   private Map<Integer, Route> _routeMap;

   public Neighborhood() {
      this._neighborhoodslist = new HashMap<>();
      this._routeMap = new HashMap<>();
   }

   public void addRoute(Route route) {
      _neighborhoodslist.putIfAbsent(route.getStart(), new ArrayList<>());
      _neighborhoodslist.putIfAbsent(route.getEnd(), new ArrayList<>());
      _neighborhoodslist.get(route.getStart()).add(route);
      _neighborhoodslist.get(route.getEnd()).add(new Route(route.getEnd(), route.getStart(), route.getRoadLength(), route.getId()));
      _routeMap.put(route.getId(), route);
   }

   public List<Route> getRoutes(String point) {
      return _neighborhoodslist.getOrDefault(point, new ArrayList<>());
   }

   public Set<String> getNeighborhoodCity() {
      return _neighborhoodslist.keySet();
   }

   public Route getRouteById(int id) {
      return _routeMap.get(id);
   }
}
