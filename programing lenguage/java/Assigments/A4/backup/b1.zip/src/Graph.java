import java.util.*;

public class Graph {
   private Map<String, List<Route>> adjList;
   private Map<Integer, Route> routeMap; // Route ID'lerine göre rotaları saklar

   public Graph() {
      this.adjList = new HashMap<>();
      this.routeMap = new HashMap<>();
   }

   public void addRoute(Route route) {
      adjList.putIfAbsent(route.getStart(), new ArrayList<>());
      adjList.putIfAbsent(route.getEnd(), new ArrayList<>());
      adjList.get(route.getStart()).add(route);
      adjList.get(route.getEnd()).add(new Route(route.getEnd(), route.getStart(), route.getDistance(), route.getId()));
      routeMap.put(route.getId(), route);
   }

   public List<Route> getRoutes(String point) {
      return adjList.getOrDefault(point, new ArrayList<>());
   }

   public Set<String> getPoints() {
      return adjList.keySet();
   }

   public Route getRouteById(int id) {
      return routeMap.get(id);
   }
}
