import java.io.*;
import java.util.*;

public class ReadFile {
   public static Graph readGraphFromFile(String inputFile) throws IOException {
      BufferedReader reader = new BufferedReader(new FileReader(inputFile));
      Graph graph = new Graph();
      List<Route> allRoutes = new ArrayList<>();

      String line ;
      while ((line = reader.readLine()) != null) {
         String[] parts = line.split("\t");
         String start = parts[0];
         String end = parts[1];
         int distance = Integer.parseInt(parts[2]);
         int id = Integer.parseInt(parts[3]);
         Route route = new Route(start, end, distance, id);
         graph.addRoute(route);
         allRoutes.add(route);
      }
      reader.close();
      return graph;
   }

   public static String[] readStartAndEndPoints(String inputFile) throws IOException {
      BufferedReader br = new BufferedReader(new FileReader(inputFile));
      String line = br.readLine(); // Start and end points line
      br.close();
      return line.split("\t");
   }
}
