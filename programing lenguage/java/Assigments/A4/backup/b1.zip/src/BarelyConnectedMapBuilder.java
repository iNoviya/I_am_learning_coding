import java.util.*;

public class BarelyConnectedMapBuilder {
   public List<Route> findBarelyConnectedMap(List<Route> allRoutes, int pointCount) {
      allRoutes.sort(Comparator.comparingInt(Route::getDistance).thenComparingInt(Route::getId));
      Map<String, String> parent = new HashMap<>();
      for (Route route : allRoutes) {
         parent.putIfAbsent(route.getStart(), route.getStart());
         parent.putIfAbsent(route.getEnd(), route.getEnd());
      }

      List<Route> result = new ArrayList<>();
      for (Route route : allRoutes) {
         String root1 = findRoot(route.getStart(), parent);
         String root2 = findRoot(route.getEnd(), parent);
         if (!root1.equals(root2)) {
            result.add(route);
            parent.put(root1, root2);
         }
         if (result.size() == pointCount - 1) break;
      }
      return result;
   }

   private String findRoot(String point, Map<String, String> parent) {
      while (!parent.get(point).equals(point)) {
         parent.put(point, parent.get(parent.get(point)));
         point = parent.get(point);
      }
      return point;
   }
}
