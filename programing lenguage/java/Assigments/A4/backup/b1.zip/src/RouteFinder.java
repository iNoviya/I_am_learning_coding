import java.util.*;

public class RouteFinder {
   public List<Route> findFastestRoute(Graph graph, String startPoint, String endPoint) {
      Map<String, Integer> distances = new HashMap<>();
      Map<String, Route> previous = new HashMap<>();
      PriorityQueue<String> pq = new PriorityQueue<>(Comparator.comparingInt(distances::get));
      Set<String> visited = new HashSet<>();

      for (String point : graph.getPoints()) {
         distances.put(point, Integer.MAX_VALUE);
      }
      distances.put(startPoint, 0);
      pq.add(startPoint);

      while (!pq.isEmpty()) {
         String current = pq.poll();
         if (!visited.add(current)) continue;

         List<Route> routes = graph.getRoutes(current);
         routes.sort(Comparator.comparingInt(Route::getDistance).thenComparingInt(Route::getId));

         for (Route route : routes) {
            if (visited.contains(route.getEnd())) continue;
            int newDist = distances.get(current) + route.getDistance();
            if (newDist < distances.get(route.getEnd())) {
               distances.put(route.getEnd(), newDist);
               previous.put(route.getEnd(), route);
               pq.add(route.getEnd());
            }
         }
      }

      List<Route> path = new ArrayList<>();
      for (Route at = previous.get(endPoint); at != null; at = previous.get(at.getStart())) {
         path.add(at);
      }
      Collections.reverse(path);
      return path;
   }
}
