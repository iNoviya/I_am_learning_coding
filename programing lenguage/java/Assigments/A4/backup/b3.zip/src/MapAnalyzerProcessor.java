import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MapAnalyzerProcessor {
   public void process(String inputFile, String outputFile) throws IOException {

      FileHandler fileHandler = new FileHandler();

      DijkstraAlgorithm dijkstraAlgorithm = new DijkstraAlgorithm();
      KruskalAlgorithm kruskalAlgorithm = new KruskalAlgorithm();

      List<Route> allRoutes = new ArrayList<>();
      Neighborhood neighborhood = fileHandler.readFile(inputFile, allRoutes);
      String startPoint = fileHandler.getStartPoint();
      String endPoint = fileHandler.getEndPoint();

      List<Route> fastestRoute = dijkstraAlgorithm.findFastestRoute(neighborhood, startPoint, endPoint);
      List<Route> barelyConnectedMap = kruskalAlgorithm.findBarelyConnectedMap(allRoutes);
      List<Route> fastestRouteBarelyConnected = dijkstraAlgorithm.findFastestRoute(new Neighborhood() {{
         barelyConnectedMap.forEach(this::addConnection);
      }}, startPoint, endPoint);



      int originalDistance = fastestRoute.stream().mapToInt(Route::getRoadLength).sum();
      int barelyConnectedDistance = fastestRouteBarelyConnected.stream().mapToInt(Route::getRoadLength).sum();
      int originalMaterial = allRoutes.stream().mapToInt(Route::getRoadLength).sum();
      int barelyConnectedMaterial = barelyConnectedMap.stream().mapToInt(Route::getRoadLength).sum();

      fileHandler.writeOutput(outputFile, fastestRoute, barelyConnectedMap, fastestRouteBarelyConnected, startPoint, endPoint, originalDistance, barelyConnectedDistance, originalMaterial, barelyConnectedMaterial);
   }


}
