import java.io.*;
import java.util.*;

public class MapAnalyzer {
   public static void main(String[] args) throws IOException {
      if (args.length != 2) {
         System.err.println("ERROR ::: ");
         return;
      }

      String inputFile = args[0];
      String outputFile = args[1];


      MapAnalyzerProcessor mapAnalyzerProcessor = new MapAnalyzerProcessor();
      mapAnalyzerProcessor.process(inputFile,outputFile);
   }
}
