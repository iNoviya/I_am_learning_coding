import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class BookingSystem {
   public static void main(String[] args) throws IOException {

      IO io = new IO(args[0]);

      OperationSystem operationSystem = new OperationSystem();
      operationSystem.setInputList(io.readFile());

      operationSystem.handleCommands();
      GlobalLogger.openFile(args[1]);
      GlobalLogger.dumpLogsToFile();
      GlobalLogger.closeFile();

      IO trimFile = new IO(args[1]);
      List<String> trimList = trimFile.readFile();
      try (BufferedWriter writer = new BufferedWriter(new FileWriter(args[1]))) {
         for (int i = 0; i < trimList.size(); i++) {
            if (i != trimList.size() - 1) {
               writer.write(trimList.get(i));
               writer.newLine();
               writer.flush();
            } else {
               writer.write(trimList.get(i));
            }

         }
      } catch (IOException e) {
         System.out.println("Error writing to the file: " + e.getMessage());
      }
   }
}