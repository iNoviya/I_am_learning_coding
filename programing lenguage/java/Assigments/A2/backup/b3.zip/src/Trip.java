import java.util.*;

public class Trip {
   private final Vehicles _vehicles;
   private double _sellAmount;
   private double _refundAmount;
   private double _cancelAmount;

   public Trip(Vehicles vehicles) {
      this._vehicles = vehicles;
   }

   public void setCancelAmount(double e) {
      this._cancelAmount = e;
   }

   public double getCancelAmount() {
      return this._cancelAmount;
   }

   public Boolean checkSell(List<Integer> seatsNumbers) {
      List<Boolean> seats = _vehicles.getFullness();
      for (int seatNumber : seatsNumbers) {
         if (seats.get(seatNumber - 1)) {
            return false;
         }
      }
      return true;
   }

   public Boolean checkRefund(List<Integer> seatsNumbers) {
      List<Boolean> seats = _vehicles.getFullness();
      for (int seatNumber : seatsNumbers) {
         if (!seats.get(seatNumber - 1)) {
            return false;
         }
      }
      return true;
   }


   public void sellTicket(List<Integer> seatsNumber) {
      List<Boolean> seats = _vehicles.getFullness();

      for (int seatNumber : seatsNumber) {
         if (!seats.get(seatNumber - 1)) {
            seats.set(seatNumber - 1, true);
         }
      }
      double sellAmount = 0.00;
      if (_vehicles instanceof Premium) {
         for (int seatNumber : seatsNumber) {
            if (seatNumber % 3 == 1) {
               sellAmount += ((Premium) _vehicles).getPremiumPrice();
            } else sellAmount += _vehicles.getPrice();
         }
      } else {
         sellAmount += _vehicles.getPrice() * seatsNumber.size();

      }
      setSellAmount(sellAmount);
      _vehicles.setRevenue(_vehicles._revenue + sellAmount);
   }

   public boolean checkRefundMinibus() {
      if (_vehicles instanceof Minibus) {
         GlobalLogger.log("ERROR: Minibus tickets are not refundable!");
         return false;
      } else return true;
   }

   public void setRefundAmount(double e) {
      this._refundAmount = e;
   }

   public double getRefundAmount() {
      return this._refundAmount;
   }

   public void setSellAmount(double e) {
      this._sellAmount = e;
   }

   public double getSellAmount() {
      return this._sellAmount;
   }

   public void refundTickets(List<Integer> seatsNumbers) {
      List<Boolean> seats = _vehicles.getFullness();

      double refundAmount = 0.00;

      for (int seatNumber : seatsNumbers) {
         if (seats.get(seatNumber - 1)) {
            seats.set(seatNumber - 1, false);
         }
      }
      if (_vehicles instanceof Premium) {
         for (int seatNumber : seatsNumbers) {
            if (seatNumber % 3 == 1) {
               refundAmount += ((Premium) _vehicles).getPremiumPrice() * ((double) (100 - ((Premium) _vehicles).getCuts()) / 100);
            } else refundAmount += _vehicles.getPrice() * ((double) (100 - ((Premium) _vehicles).getCuts()) / 100);
         }
      } else if (_vehicles instanceof Standard) {
         refundAmount += _vehicles.getPrice() * (100 - (double) ((Standard) _vehicles).getCuts()) / 100 * seatsNumbers.size();
      }
      setRefundAmount(refundAmount);
      _vehicles.setRevenue(_vehicles.getRevenue() - refundAmount);
   }

   public void cancelAmountPrice() {
      List<Boolean> seats = _vehicles.getFullness();
      double cancelAmount = 0.00;
      for (int i = 0; i < seats.size(); i++) {
         if (seats.get(i)) {
            if (_vehicles instanceof Premium) {
               if (i % 3 == 1) {
                  cancelAmount += ((Premium) _vehicles).getPremiumPrice();
               } else cancelAmount += _vehicles.getPrice();
            } else if (_vehicles instanceof Standard) {
               cancelAmount += ((Standard) _vehicles).getPrice();
            } else if (_vehicles instanceof Minibus) {
               cancelAmount += ((Minibus) _vehicles).getPrice();
            }
         }
      }
      setCancelAmount(cancelAmount);
      _vehicles.setRevenue(_vehicles.getRevenue() - cancelAmount);
   }
}
