import java.util.*;

public class OperationSystem {

   private List<String> _inputList;
   private List<Vehicles> _vehiclesList = new ArrayList<>();

   public void setInputList(List<String> inputList) {
      this._inputList = inputList;
   }

   public List<String> getInputList() {
      return _inputList;
   }


   public void handleCommands() {
      for (String line : _inputList) {
         System.out.println(line);
         GlobalLogger.log("COMMAND: " + line);
         String[] splited = line.split("\t");
         String parameter = splited[0].trim();
         if (ErrorLogger.getInstance().commendCheck(splited)){
            switch (parameter) {
               case "INIT_VOYAGE": {
                  if (controlVague(Integer.parseInt(splited[2]))){
                     if (ErrorLogger.getInstance().checkParameter(splited)){
                        if (splited[1].equals("Premium")) {
                           Premium premium = new Premium(splited[1], Integer.parseInt(splited[2]), splited[3], splited[4], Integer.parseInt(splited[5]), Double.parseDouble(splited[6]), Integer.parseInt(splited[7]), Integer.parseInt(splited[8]));
                           premium.setRevenue(0.00);
                           _vehiclesList.add(premium);
                           premium.setVoyageInfo();
                        } else if (splited[1].equals("Standard")) {
                           Standard standard = new Standard(splited[1], Integer.parseInt(splited[2]), splited[3], splited[4], Integer.parseInt(splited[5]), Double.parseDouble(splited[6]), Integer.parseInt(splited[7]));
                           standard.setRevenue(0.00);
                           _vehiclesList.add(standard);
                           standard.setVoyageInfo();

                        } else if (splited[1].equals("Minibus")) {
                           Minibus minibus = new Minibus(splited[1], Integer.parseInt(splited[2]), splited[3], splited[4], Integer.parseInt(splited[5]), Double.parseDouble(splited[6]));
                           minibus.setRevenue(0.00);
                           _vehiclesList.add(minibus);
                           minibus.setVoyageInfo();
                        }
                        break;
                     }
                  }
                  break;
               }
               case "Z_REPORT": {
                  if (!_vehiclesList.isEmpty()) {
                     GlobalLogger.log("Z Report:");
                     GlobalLogger.log("----------------");
                     _vehiclesList.sort(Comparator.comparingInt(Vehicles::getId));
                     for (Vehicles vehicle : _vehiclesList) {
                        vehicle.zReport();
                     }
                  } else {
                     GlobalLogger.log("Z Report:");
                     GlobalLogger.log("----------------");
                     GlobalLogger.log("No Voyages Available!");
                     GlobalLogger.log("----------------");
                  }
                  break;
               }
               case "PRINT_VOYAGE": {
                  int index = findIndexOfId(Integer.parseInt(splited[1]));

                  if (index >= 0) {
                     _vehiclesList.get(index).printVoyage();
                     break;
                  } else {
                     GlobalLogger.log("No Voyages Available!");
                     break;
                  }
               }
               case "SELL_TICKET": {
                  int index = findIndexOfId(Integer.parseInt(splited[1]));
                  List<Integer> ticketsNumbers = createTicketsList(splited[2],index);
                  if (ErrorLogger.getInstance().checkIndex(index)){
                     int flag = 0;
                     for (int ticketNo : ticketsNumbers){
                        if (ticketNo < 0){
                           GlobalLogger.log("ERROR: "+ ticketNo +" is not a positive integer, seat number must be a positive integer!");
                           flag =1;
                           break;
                        } else if (ticketNo > _vehiclesList.get(index)._seats) {
                           GlobalLogger.log("ERROR: There is no such a seat!");
                           flag =1;
                           break;
                        }
                     }
                     if (flag != 1 ){
                        Trip trip = new Trip(_vehiclesList.get(index));
                        if (trip.checkSell(ticketsNumbers)) {
                           trip.sellTicket(ticketsNumbers);
                           StringBuilder text = new StringBuilder();
                           for (int number : ticketsNumbers) {
                              text.append(number).append("-");
                           }
                           if (text.length()-1 >= 0){
                              GlobalLogger.log("Seat " + text.substring(0, text.length() - 1) + " of the Voyage " + _vehiclesList.get(index)._id + " from " + _vehiclesList.get(index)._boarding + " to " + _vehiclesList.get(index)._landing + " was successfully sold for " + String.format("%.2f", trip.getSellAmount()) + " TL.");
                           }
                        } else GlobalLogger.log("ERROR: One or more seats already sold!");
                     }
                  }

                  break;
               }
               case "REFUND_TICKET": {
                  int index = findIndexOfId(Integer.parseInt(splited[1]));
                  List<Integer> ticketsNumbers = createTicketsList(splited[2] , index);

                  if (ErrorLogger.getInstance().checkIndex(index)){
                     int flag = 0;
                     for (int ticketNo : ticketsNumbers){
                        if (ticketNo < 0){
                           GlobalLogger.log("ERROR: "+ ticketNo +" is not a positive integer, seat number must be a positive integer!");
                           flag =1;
                           break;
                        } else if (ticketNo > _vehiclesList.get(index)._seats) {
                           GlobalLogger.log("ERROR: There is no such a seat!");
                           flag =1;
                           break;
                        }
                     }
                     if (flag != 1){
                        Trip trip = new Trip(_vehiclesList.get(index));
                        if (trip.checkRefund(ticketsNumbers)) {
                           for (int i : ticketsNumbers){
                              if (i<0  || i > _vehiclesList.get(index)._seats) {
                                 GlobalLogger.log("ERROR: There is no such a seat!");
                                 break;
                              }
                           }
                           if (trip.checkRefundMinibus()) {
                              trip.refundTickets(ticketsNumbers);
                              String text = "";
                              for (int number : ticketsNumbers) {
                                 text += number + "-";
                              }
                              if (text.length() -1 >=0){
                                 GlobalLogger.log("Seat " + text.substring(0, text.length() - 1) + " of the Voyage " + _vehiclesList.get(index)._id + " from " + _vehiclesList.get(index)._boarding + " to " + _vehiclesList.get(index)._landing + " was successfully refunded for " + String.format("%.2f", trip.getRefundAmount()) + " TL.");
                              }
                           }
                        } else GlobalLogger.log("ERROR: One or more seats are already empty!\n");
                     }
                  }
                  break;
               }
               case "CANCEL_VOYAGE": {
                  int index = findIndexOfId(Integer.parseInt(splited[1]));
                  if (ErrorLogger.getInstance().checkIndex(index)){
                     Trip trip = new Trip(_vehiclesList.get(index));
                     trip.cancelAmountPrice();
                     GlobalLogger.log("Voyage " + _vehiclesList.get(index)._id + " was successfully cancelled!");
                     GlobalLogger.log("Voyage details can be found below:");
                     _vehiclesList.get(index).printVoyage();
                     _vehiclesList.remove(index);
                  }
                  break;
               }

            }
         }

      }
      if (!_inputList.get(_inputList.size() - 1).equals("Z_REPORT")) {
         GlobalLogger.log("Z Report:");
         GlobalLogger.log("----------------");
         if (_vehiclesList.isEmpty()) {
            GlobalLogger.log("No Voyages Available!");
            GlobalLogger.log("----------------");
         } else {
            _vehiclesList.sort(Comparator.comparingInt(Vehicles::getId));
            for (Vehicles vehicle : _vehiclesList) {
               vehicle.zReport();
            }
         }
      }
   }

   private int findIndexOfId(int searchId) {
      for (int i = 0; i < _vehiclesList.size(); i++) {
         if (_vehiclesList.get(i).getId() == searchId) {
            return i;
         }
      }
      GlobalLogger.log("ERROR: There is no voyage with ID of "+ searchId +"!");
      return -1;
   }

   private List<Integer> createTicketsList(String text,int index) {

      String[] line = text.split("_");
      List<Integer> ticketsNumbers = new ArrayList<>();
      for (String ticketNumber : line) {
         ticketsNumbers.add(Integer.parseInt(ticketNumber));
      }
      return ticketsNumbers;
   }
   public boolean controlVague (int id ){
      for (int i = 0; i < _vehiclesList.size() ; i++) {
         if (_vehiclesList.get(i)._id == id){
            GlobalLogger.log("ERROR: There is already a voyage with ID of " + id + "!");
            return false;
         }
      }
      return true;
   }
}