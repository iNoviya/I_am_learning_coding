import java.util.*;

public class OperationSystem {

   private List<String> _inputList;
   private List<Bus> _busList = new ArrayList<>();

   public void setInputList(List<String> inputList) {
      this._inputList = inputList;
   }

   public List<String> getInputList() {
      return _inputList;
   }


   public void handleCommands() {
      for (String line : _inputList) {
         GlobalLogger.log("COMMAND: " + line);
         String[] splited = line.split("\t");
         String parameter = splited[0].trim();
         if (ErrorLogger.getInstance().commendLengthCheck(splited)) {
            switch (parameter) {
               case "INIT_VOYAGE": {
                  if (ErrorLogger.getInstance().checkParameterInitVoyage(splited)) {
                     if (isVoyageIdUnique(Integer.parseInt(splited[2]))){
                        if (splited[1].equals("Premium")) {
                           Premium premium = new Premium(splited[1], Integer.parseInt(splited[2]), splited[3], splited[4], Integer.parseInt(splited[5]), Double.parseDouble(splited[6]), Integer.parseInt(splited[7]), Integer.parseInt(splited[8]));
                           premium.setRevenue(0.00);
                           _busList.add(premium);
                           premium.setVoyageInfo();
                        } else if (splited[1].equals("Standard")) {
                           Standard standard = new Standard(splited[1], Integer.parseInt(splited[2]), splited[3], splited[4], Integer.parseInt(splited[5]), Double.parseDouble(splited[6]), Integer.parseInt(splited[7]));
                           standard.setRevenue(0.00);
                           _busList.add(standard);
                           standard.setVoyageInfo();

                        } else if (splited[1].equals("Minibus")) {
                           Minibus minibus = new Minibus(splited[1], Integer.parseInt(splited[2]), splited[3], splited[4], Integer.parseInt(splited[5]), Double.parseDouble(splited[6]));
                           minibus.setRevenue(0.00);
                           _busList.add(minibus);
                           minibus.setVoyageInfo();
                        }
                     } else GlobalLogger.log("ERROR: There is already a voyage with ID of " + splited[2] + "!");
                  }
                  break;
               }
               case "Z_REPORT": {
                  if (!_busList.isEmpty()) {
                     GlobalLogger.log("Z Report:");
                     GlobalLogger.log("----------------");
                     _busList.sort(Comparator.comparingInt(Bus::getId));
                     for (Bus bus : _busList) {
                        bus.zReport();
                     }
                  } else {
                     GlobalLogger.log("Z Report:");
                     GlobalLogger.log("----------------");
                     GlobalLogger.log("No Voyages Available!");
                     GlobalLogger.log("----------------");
                  }
                  break;
               }
               case "PRINT_VOYAGE": {
                  int searchedID = Integer.parseInt(splited[1]);
                  if (searchedID > 0) {
                     int index = findIndexOfId(Integer.parseInt(splited[1]));
                     if (index >= 0) {
                        _busList.get(index).printVoyage();
                     }
                     /*if (controlVagueId(searchedID) ) {

                     } else GlobalLogger.log("No Voyages Available!");
                     /*if (index >= 0) {
                        _busList.get(index).printVoyage();
                     }*/
                  } else
                     GlobalLogger.log("ERROR: " + searchedID + " is not a positive integer, ID of a voyage must be a positive integer!");
                  break;
               }
               case "SELL_TICKET": {
                  int index = findIndexOfId(Integer.parseInt(splited[1]));
                  List<Integer> ticketsNumbers = createTicketsList(splited[2], index);
                  if (ErrorLogger.getInstance().checkIndex(index) && ErrorLogger.getInstance().checkParameterSellTicket(splited, ticketsNumbers, _busList.get(index)._seats)) {
                     Trip trip = new Trip(_busList.get(index));
                     if (trip.checkSell(ticketsNumbers)) {
                        trip.sellTicket(ticketsNumbers);
                        StringBuilder text = new StringBuilder();
                        for (int number : ticketsNumbers) {
                           text.append(number).append("-");
                        }
                        if (text.length() - 1 >= 0) {
                           GlobalLogger.log("Seat " + text.substring(0, text.length() - 1) + " of the Voyage " + _busList.get(index)._id + " from " + _busList.get(index)._boarding + " to " + _busList.get(index)._landing + " was successfully sold for " + String.format("%.2f", trip.getSellAmount()) + " TL.");
                        }
                     }
                  }

                  break;
               }
               case "REFUND_TICKET": {
                  int index = findIndexOfId(Integer.parseInt(splited[1]));
                  List<Integer> ticketsNumbers = createTicketsList(splited[2], index);
                  if (index >= 0) {
                     if (ErrorLogger.getInstance().checkParameterRefundTicket(splited, ticketsNumbers, _busList.get(index)._seats)) {
                        Trip trip = new Trip(_busList.get(index));
                        if (trip.checkRefund(ticketsNumbers)) {
                           if (trip.checkRefundMinibus()) {
                              trip.refundTickets(ticketsNumbers);
                              String text = "";
                              for (int number : ticketsNumbers) {
                                 text += number + "-";
                              }
                              if (text.length() - 1 >= 0) {
                                 GlobalLogger.log("Seat " + text.substring(0, text.length() - 1) + " of the Voyage " + _busList.get(index)._id + " from " + _busList.get(index)._boarding + " to " + _busList.get(index)._landing + " was successfully refunded for " + String.format("%.2f", trip.getRefundAmount()) + " TL.");
                              }
                           }
                        } else GlobalLogger.log("ERROR: One or more seats are already empty!");
                     }
                  }
                  break;
               }
               case "CANCEL_VOYAGE": {
                  int searchedID = Integer.parseInt(splited[1]);
                  int index = 0;

                  boolean isVoyageID = _busList.stream().anyMatch(bus -> bus.getId() == searchedID);

                  for (int i = 0; i < _busList.size(); i++) {
                     if (_busList.get(i).getId() == searchedID) {
                        index = i;
                     }
                  }
                  if (ErrorLogger.getInstance().checkIndexCancel(index)) {
                     if (ErrorLogger.getInstance().checkParameterCancelVoyage(searchedID)) {
                        if (!isVoyageID) {
                           GlobalLogger.log("ERROR: There is no voyage with ID of " + searchedID + "!");
                        } else {
                           Trip trip = new Trip(_busList.get(index));
                           trip.cancelAmountPrice();
                           GlobalLogger.log("Voyage " + _busList.get(index)._id + " was successfully cancelled!");
                           GlobalLogger.log("Voyage details can be found below:");
                           _busList.get(index).printVoyage();
                           _busList.remove(index);
                        }
                     }
                  } else {
                     GlobalLogger.log("ERROR: " + searchedID + " is not a positive integer, ID of a voyage must be a positive integer!");
                  }
                  break;
               }
            }
         }

      }
      if (!_inputList.get(_inputList.size() - 1).equals("Z_REPORT")) {
         GlobalLogger.log("Z Report:");
         GlobalLogger.log("----------------");
         if (_busList.isEmpty()) {
            GlobalLogger.log("No Voyages Available!");
            GlobalLogger.log("----------------");
         } else {
            _busList.sort(Comparator.comparingInt(Bus::getId));
            for (Bus bus : _busList) {
               bus.zReport();
            }
         }
      }
   }

   private int findIndexOfId(int searchId) {
      for (int i = 0; i < _busList.size(); i++) {
         if (_busList.get(i).getId() == searchId) {
            return i;
         }
      }
      GlobalLogger.log("ERROR: There is no voyage with ID of " + searchId + "!");
      return -1;
   }

   private List<Integer> createTicketsList(String text, int index) {

      String[] line = text.split("_");
      List<Integer> ticketsNumbers = new ArrayList<>();
      for (String ticketNumber : line) {
         ticketsNumbers.add(Integer.parseInt(ticketNumber));
      }
      return ticketsNumbers;
   }

   public boolean isVoyageIdUnique(int id) {
      for (int i = 0; i < _busList.size(); i++) {
         if (_busList.get(i)._id == id) {
            return false;
         }
      }
      return true;
   }
}