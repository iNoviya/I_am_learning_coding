import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class GlobalLogger {
    private static List<String> logMessages = new ArrayList<>();
    private static PrintWriter writer = null;

    public static synchronized void log(String message) {
        logMessages.add(message);
    }

    public static void openFile(String filename) {
        if (writer != null) {
            writer.close();
        }
        try {
            writer = new PrintWriter(filename);
        } catch (IOException e) {
            System.err.println("Error opening log file: " + e.getMessage());
        }
    }

    public static void dumpLogsToFile() {
        if (writer != null) {
            for (String logMessage : logMessages) {
                writer.println(logMessage);
            }
            writer.flush();
        }
    }

    public static void closeFile() {
        if (writer != null) {
            writer.close();
            writer = null;
        }
    }
}
