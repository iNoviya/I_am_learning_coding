import java.util.*;

public class Trip {
   private final Bus _bus;
   private double _sellAmount;
   private double _refundAmount;
   private double _cancelAmount;

   public Trip(Bus bus) {
      this._bus = bus;
   }

   public void setRefundAmount(double e) {
      this._refundAmount = e;
   }

   public double getRefundAmount() {
      return this._refundAmount;
   }

   public void setSellAmount(double e) {
      this._sellAmount = e;
   }

   public double getSellAmount() {
      return this._sellAmount;
   }
   public void setCancelAmount(double e) {
      this._cancelAmount = e;
   }

   public double getCancelAmount() {
      return this._cancelAmount;
   }

   public Boolean checkSell(List<Integer> seatsNumbers) {
      List<Boolean> seats = _bus.getFullness();
      for (int seatNumber : seatsNumbers) {
         if (seats.get(seatNumber - 1)) {
            GlobalLogger.log("ERROR: One or more seats already sold!");
            return false;
         }
      }
      return true;
   }

   public Boolean checkRefund(List<Integer> seatsNumbers) {
      List<Boolean> seats = _bus.getFullness();
      for (int seatNumber : seatsNumbers) {
         if (!seats.get(seatNumber - 1)) {
            return false;
         }
      }
      return true;
   }


   public void sellTicket(List<Integer> seatsNumber) {
      List<Boolean> seats = _bus.getFullness();

      for (int seatNumber : seatsNumber) {
         if (!seats.get(seatNumber - 1)) {
            seats.set(seatNumber - 1, true);
         }
      }
      double sellAmount = 0.00;
      if (_bus instanceof Premium) {
         for (int seatNumber : seatsNumber) {
            if (seatNumber % 3 == 1) {
               sellAmount += ((Premium) _bus).getPremiumPrice();
            } else sellAmount += _bus.getPrice();
         }
      } else {
         sellAmount += _bus.getPrice() * seatsNumber.size();

      }
      setSellAmount(sellAmount);
      _bus.setRevenue(_bus._revenue + sellAmount);
   }

   public boolean checkRefundMinibus() {
      if (_bus instanceof Minibus) {
         GlobalLogger.log("ERROR: Minibus tickets are not refundable!");
         return false;
      } else return true;
   }


   public void refundTickets(List<Integer> seatsNumbers) {
      List<Boolean> seats = _bus.getFullness();

      double refundAmount = 0.00;

      for (int seatNumber : seatsNumbers) {
         if (seats.get(seatNumber - 1)) {
            seats.set(seatNumber - 1, false);
         }
      }
      if (_bus instanceof Premium) {
         for (int seatNumber : seatsNumbers) {
            if (seatNumber % 3 == 1) {
               refundAmount += ((Premium) _bus).getPremiumPrice() * ((double) (100 - ((Premium) _bus).getCuts()) / 100);
            } else refundAmount += _bus.getPrice() * ((double) (100 - ((Premium) _bus).getCuts()) / 100);
         }
      } else if (_bus instanceof Standard) {
         refundAmount += _bus.getPrice() * (100 - (double) ((Standard) _bus).getCuts()) / 100 * seatsNumbers.size();
      }
      setRefundAmount(refundAmount);
      _bus.setRevenue(_bus.getRevenue() - refundAmount);
   }

   public void cancelAmountPrice() {
      List<Boolean> seats = _bus.getFullness();
      double cancelAmount = 0.00;
      for (int i = 0; i < seats.size(); i++) {
         if (seats.get(i)) {
            if (_bus instanceof Premium) {
               if (i % 3 == 0) {
                  cancelAmount += ((Premium) _bus).getPremiumPrice();
               } else cancelAmount += _bus.getPrice();
            } else if (_bus instanceof Standard) {
               cancelAmount += ((Standard) _bus).getPrice();
            } else if (_bus instanceof Minibus) {
               cancelAmount += ((Minibus) _bus).getPrice();
            }
         }
      }
      setCancelAmount(cancelAmount);
      _bus.setRevenue(_bus.getRevenue() - cancelAmount);
   }
}