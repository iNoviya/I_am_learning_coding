import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public abstract class Bus {

   int _id;
   String _type;
   String _boarding;
   String _landing;
   static int _rows;
   double _price;
   int _seats;
   List<Boolean> _fullness;
   double _revenue;


   public Bus(String type, int id, String boarding, String landing, int rows, double price) {
      this._id = id;
      this._type = type;
      this._boarding = boarding;
      this._landing = landing;
      this._rows = rows;
      this._price = price;
      this._seats = numberOfSeats();
      this._fullness = new ArrayList<>(Collections.nCopies(_seats, false));
   }


   public abstract int numberOfSeats();

   public abstract void zReport();

   public abstract void printVoyage();

   public abstract void setVoyageInfo();

   public int getId() {
      return this._id;
   }


   public List<Boolean> getFullness() {
      return _fullness;
   }

   public double getRevenue() {
      return this._revenue;
   }

   public void setRevenue(double revenue) {
      this._revenue = revenue;
   }

   public double getPrice() {
      return this._price;
   }
}
